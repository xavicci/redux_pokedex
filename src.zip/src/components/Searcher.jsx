import { Input } from "antd";

export const Searcher = () => {
  return <Input.Search placeholder="Buscar..." />;
};
